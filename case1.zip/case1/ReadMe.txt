DrillDown Enabled only for
State - Maharastra
Division - Pune
District - Solapur
Tehsil - Phandrapur(Last level of Drill down)
Further States SVG can be downloaded to enable DrillDown

One Click Event shows data.
Double Click Event Drills Down into the map;

**Important** Click on Pune Divison TextField to drill down to next level

Open index.html