Dependencies
1)Tessaract-To get OCR of image
2)jxl- to read/write from Excel Sheet

Instructions:-
1) Modify Destination/Source of files according to your system
2) Create a ocr.txt file and modify the path in Main.java and ocr.java

Database is stored in Book1.xls as sample data