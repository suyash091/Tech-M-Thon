/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Case2;

/**
 *
 * @author Prashant Varshney
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadId 
{
   public static String ReadText(File input) throws IOException 
   {
     
      String[] words=null;  //Intialize the word Array
      FileReader fr = new FileReader(input);  //Creation of File Reader object
      BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
      String s;     
      String key="ID";   // Input word to be searched
      int i=0;
      boolean check=false;//Intialize the word to zero
      while((s=br.readLine())!=null)   //Reading Content from the file
      {
         words=s.split(" ");  //Split the word using space
          for (i=0;i<words.length-1;i++) 
          {
  
                 if (words[i].matches(key))   //Search for the given word
                 {
                   check=true;
                  // System.out.println(words[i]);
                   return words[i+1];
                   //If Present increase the count by one
                 }
                 if(check)
                 {
                	break;
                 }
          }
      }
      fr.close();
//      if(check)
    	  return "-1";
   }


}
