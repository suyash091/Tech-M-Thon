/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Case2;

/**
 *
 * @author Prashant Varshney
 */
import java.io.File;  
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;  
import jxl.Cell;  
import jxl.Sheet;  
import jxl.*;
import jxl.read.biff.BiffException;
import jxl.write.*;
import jxl.Workbook;
import jxl.write.Number;
import java.io.*;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import jxl.format.UnderlineStyle;
import jxl.write.biff.RowsExceededException;
  
public class WriteExcel { 
    
     private WritableCellFormat timesBoldUnderline;
    private WritableCellFormat times;
    private String inputFile="C:\\\\Users\\\\Prashant Varshney\\Documents\\Book1.xls";
    
    public void writeData(String[] userData,boolean id) throws IOException, WriteException, BiffException {
    Workbook workbook=Workbook.getWorkbook(new File(inputFile)); 
     final File  outputWorkbook;     
         Sheet readsheet=workbook.getSheet(0);
         System.out.println(readsheet.getName());  
         outputWorkbook = new File("c:\\Users\\Prashant Varshney\\Documents\\temp.xls");                            // the excel sheet where data is to copied
         WritableWorkbook workbook1=Workbook.createWorkbook(outputWorkbook,workbook);
          WritableSheet sheet1 = workbook1.getSheet(0);
         int i=0,j=0;                                                                                               //following code copies the data from sandy1 to sandy2.xls
         
         for(j=0;j<(readsheet.getColumns());j++){        
         for(i=0;i<readsheet.getRows();i++)  {          
            
          if(readsheet.getCell(j,i).getType()==(CellType.LABEL))    
          {
            
           Label Name=new Label(j,i,readsheet.getCell(j,i).getContents());
            sheet1.addCell(Name);
             
               System.out.println(readsheet.getCell(j,i).getContents()); 
          }
          if(readsheet.getCell(j,i).getType()==(CellType.NUMBER)) {   
                  
              String s=readsheet.getCell(j,i).getContents();      
         Label Name1=new Label(j,i,s);
         sheet1.addCell(Name1);
          System.out.println(readsheet.getCell(j,i).getContents());
         }               
            }
         }
         int row;
         if(!id){
             for(int z=0;z<userData.length;z++)
             {
                 System.out.println(userData[z]);
             }
            row=readsheet.getRows();
         }
         else{
             int nrow=readsheet.getRows();
             row=-1;
              String iD=userData[0];
for(int z=0;z<nrow;z++){
    Cell c=readsheet.getCell(0,z);
    if(iD.matches(c.getContents()))
    {
        row=z;
        break;
    }
} }
 for(int z=0;z<readsheet.getColumns();z++)
         {
            addContent(z,row,userData[z],sheet1);
         }         workbook1.write();
      workbook1.close();
      File file = new File("C:\\Users\\Prashant Varshney\\Documents\\Book1.xls"); 
          
        if(file.delete()) 
        { 
            System.out.println("File deleted successfully"); 
        } 
        else
        { 
            System.out.println("Failed to delete the file"); 
        } 
      File oldName = 
         new File("C:\\\\Users\\\\Prashant Varshney\\Documents\\temp.xls"); 
        File newName =  
         new File("C:\\\\Users\\\\Prashant Varshney\\Documents\\Book1.xls");
         if (oldName.renameTo(newName))  
            System.out.println("Renamed successfully");         
        else 
            System.out.println("Error");   
    }


public static void addContent(int col, int row, String s, WritableSheet Sheet) throws WriteException
{
        Label label=new Label(col,row,s);
         Sheet.addCell(label);
}
}

