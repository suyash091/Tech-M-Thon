/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Case2;

/**
 *
 * @author Prashant Varshney
 */
import java.io.File;  
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;  
import jxl.Cell;  
import jxl.Sheet;  
import jxl.*;
import jxl.read.biff.BiffException;
import jxl.write.*;
import jxl.Workbook;
import jxl.write.Number;

public class ReadExcel  
{  
@SuppressWarnings("deprecation")
public static String[] ReadData(String id)   
{  String Data[]=new String[24];
try  
{  
File file = new File("C:\\\\Users\\\\Prashant Varshney\\Documents\\Book1.xls");   //creating a new file instance  
FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file  
//creating Workbook instance that refers to .xls file  
Workbook wb = Workbook.getWorkbook(fis);
Sheet sheet = wb.getSheet(0);
int nrow=sheet.getRows();
int ID=-1;
for(int i=0;i<nrow;i++){
    Cell c=sheet.getCell(0,i);
    if(id.matches(c.getContents()))
        ID=i;
}
    int col=sheet.getColumns();
    for(int j=0;j<col;j++)
    {
        Cell c=sheet.getCell(j,ID);
        Data[j]=c.getContents();
    }
    System.out.println("Data fetched");  
}  
catch(Exception e)  
{  
e.printStackTrace();  
}  
return Data;
}  
public static boolean searchID(String id) {
	try  
	{  
File file = new File("C:\\\\Users\\\\Prashant Varshney\\Documents\\Book1.xls");   //creating a new file instance  
FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file  
//creating Workbook instance that refers to .xls file  
Workbook wb = Workbook.getWorkbook(fis);
Sheet sheet = wb.getSheet(0);
int nrow=sheet.getRows();
int ID=-1;
for(int i=0;i<nrow;i++){
    Cell c=sheet.getCell(0,i);
    if(id.matches(c.getContents()))
        return true;
}
    	
	}catch(BiffException e){
            e.printStackTrace();
        }
        catch (NullPointerException e)
	{
		e.printStackTrace();
	}
	catch (FileNotFoundException e) {
		e.printStackTrace();
	} 
	 catch (IOException e) {
			e.printStackTrace();
		}
	return false;
}
public static int []labSearch(String ID,String LabID){
	int[] LabCounts=new int[16];
		try  
	{  
File file = new File("C:\\\\Users\\\\Prashant Varshney\\Documents\\Book1.xls");   //creating a new file instance  
FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file  
//creating Workbook instance that refers to .xls file  
Workbook wb = Workbook.getWorkbook(fis);
Sheet sheet = wb.getSheet(0);
int nrow=sheet.getRows();
int ncol=sheet.getColumns();
int id=-1;
for(int i=0;i<nrow;i++){
    Cell c=sheet.getCell(0,i);
    
    if(ID.matches(c.getContents()))
        id=i;
}
for(int j=2;j<18;j++){
    Cell c=sheet.getCell(j,id);
    try{
    LabCounts[j-2]=Integer.parseInt(c.getContents());
}
    catch(NumberFormatException e)
    {
        LabCounts[j-2]=0;
        continue;
    }
}
    	
	}catch(BiffException e){
            e.printStackTrace();
        }
         catch (FileNotFoundException e) {
		e.printStackTrace();
	} 
	 catch (IOException e) {
			e.printStackTrace();
		}
	return LabCounts;
}
}  

