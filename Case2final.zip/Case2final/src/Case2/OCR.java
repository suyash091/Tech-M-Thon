/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Case2;

/**
 *
 * @author Prashant Varshney
 */
import java.io.PrintWriter;
	public class OCR {
		public static void ocrmain(String input_img,String output) {
			String input_file=input_img;
			String output_file="C:\\Users\\Prashant Varshney\\Documents\\"+output;	
			String tesseract_install_path="C:\\Program Files (x86)\\Tesseract-OCR\\tesseract";
			String[] command =
		    {
		        "cmd",
		    };
		    Process p;
			try {
				p = Runtime.getRuntime().exec(command);
			        new Thread(new SyncPipe(p.getErrorStream(), System.err)).start();
		                new Thread(new SyncPipe(p.getInputStream(), System.out)).start();
		                PrintWriter stdin = new PrintWriter(p.getOutputStream());
		                stdin.println("\""+tesseract_install_path+"\" \""+input_file+"\" \""+output_file+"\" -l eng");
		        	    stdin.close();
		                p.waitFor();
		                System.out.println();
		                System.out.println();
		                System.out.println();
		                System.out.println();
		                System.out.println(Read_File.read_a_file(output_file+".txt"));
		    	} catch (Exception e) {
		 		e.printStackTrace();
			}
		}	


	}	
