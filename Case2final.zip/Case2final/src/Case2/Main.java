/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Case2;

//import java.awt.Button;
//import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;

/**
 *
 * @author Prashant Varshney & Harsh Paliwal
 * @version  0.1
 */
public class Main extends javax.swing.JFrame {

   
    public Main() {
        
        initComponents();
       
    }
    /* Global Declerations     */
    String TId=null;
    String id=null;
    String input_img=null;
    String LabID=null;
    String userData[]=new String[24];
    String vName=null;
    String reason=null;
    String data=null;
    String timeEnter=null;
    String ph=null;
    String sheetPath=null;
    boolean idpresent=false;
    int f=0;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPane1 = new javax.swing.JDesktopPane();
        layeredPane = new javax.swing.JLayeredPane();
        EntryPanel = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        Tid = new javax.swing.JTextField();
        Entertoapp = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        LabItem = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        Panel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        fileDisplay = new javax.swing.JLabel();
        upl = new javax.swing.JButton();
        Panel2 = new javax.swing.JPanel();
        namel = new javax.swing.JLabel();
        namef = new javax.swing.JLabel();
        Vid = new javax.swing.JLabel();
        IDF = new javax.swing.JLabel();
        Next = new javax.swing.JButton();
        l1 = new javax.swing.JLabel();
        lab1c = new javax.swing.JLabel();
        l1com = new javax.swing.JComboBox<>();
        rl1 = new javax.swing.JLabel();
        rl3 = new javax.swing.JLabel();
        l2com = new javax.swing.JComboBox<>();
        lab2c = new javax.swing.JLabel();
        l4 = new javax.swing.JLabel();
        rl2 = new javax.swing.JLabel();
        l4com = new javax.swing.JComboBox<>();
        lab3c = new javax.swing.JLabel();
        l2 = new javax.swing.JLabel();
        rl4 = new javax.swing.JLabel();
        l3com = new javax.swing.JComboBox<>();
        lab4c = new javax.swing.JLabel();
        l3 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        visitedDate = new javax.swing.JLabel();
        firstVisit = new javax.swing.JLabel();
        Cancel = new javax.swing.JButton();
        Panel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        PCTID = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        PCTName = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        LABid = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        dateTime = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        LabTechID = new javax.swing.JLabel();
        reasonList = new javax.swing.JComboBox<>();
        reasoncom = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        timeAvail = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        phno = new javax.swing.JTextField();
        submit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        TechId = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 650));
        setResizable(false);

        jDesktopPane1.setPreferredSize(new java.awt.Dimension(800, 800));

        layeredPane.setPreferredSize(new java.awt.Dimension(780, 650));
        layeredPane.setLayout(new java.awt.CardLayout());

        EntryPanel.setPreferredSize(new java.awt.Dimension(780, 650));

        jLabel15.setText("Enter Technician Id");

        Entertoapp.setText("Enter");
        Entertoapp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EntertoappActionPerformed(evt);
            }
        });

        jLabel16.setText("Select Lab");

        LabItem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lab 1", "Lab 2", "Lab 3", "Lab 4" }));
        LabItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LabItemActionPerformed(evt);
            }
        });

        jButton2.setText("Exit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout EntryPanelLayout = new javax.swing.GroupLayout(EntryPanel);
        EntryPanel.setLayout(EntryPanelLayout);
        EntryPanelLayout.setHorizontalGroup(
            EntryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EntryPanelLayout.createSequentialGroup()
                .addGroup(EntryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EntryPanelLayout.createSequentialGroup()
                        .addGap(261, 261, 261)
                        .addComponent(Entertoapp, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(EntryPanelLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(EntryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(81, 81, 81)
                        .addGroup(EntryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Tid)
                            .addComponent(LabItem, 0, 191, Short.MAX_VALUE))))
                .addContainerGap(266, Short.MAX_VALUE))
        );
        EntryPanelLayout.setVerticalGroup(
            EntryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EntryPanelLayout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addGroup(EntryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Tid, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(EntryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LabItem, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(99, 99, 99)
                .addGroup(EntryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Entertoapp)
                    .addComponent(jButton2))
                .addContainerGap(323, Short.MAX_VALUE))
        );

        layeredPane.add(EntryPanel, "card5");

        jButton1.setText("Browse");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setText("Image Chosen");

        upl.setText("Upload");
        upl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uplActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Panel1Layout = new javax.swing.GroupLayout(Panel1);
        Panel1.setLayout(Panel1Layout);
        Panel1Layout.setHorizontalGroup(
            Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel1Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76)
                .addComponent(fileDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 130, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(124, 124, 124))
            .addGroup(Panel1Layout.createSequentialGroup()
                .addGap(346, 346, 346)
                .addComponent(upl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Panel1Layout.setVerticalGroup(
            Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel1Layout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fileDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(104, 104, 104)
                .addComponent(upl)
                .addContainerGap(396, Short.MAX_VALUE))
        );

        layeredPane.add(Panel1, "card2");

        namel.setText("Name");

        Vid.setText("Your ID is:");

        Next.setText("Next");
        Next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextActionPerformed(evt);
            }
        });

        l1.setText("Lab1");

        l1com.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reason 1", "Reason 2", "Reason 3", "Reason 4" }));
        l1com.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l1comActionPerformed(evt);
            }
        });

        l2com.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reason 1", "Reason 2", "Reason 3", "Reason 4" }));
        l2com.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l2comActionPerformed(evt);
            }
        });

        l4.setText("Lab4");

        l4com.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reason 1", "Reason 2", "Reason 3", "Reason 4" }));
        l4com.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l4comActionPerformed(evt);
            }
        });

        l2.setText("Lab2");

        l3com.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reason 1", "Reason 2", "Reason 3", "Reason 4" }));
        l3com.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l3comActionPerformed(evt);
            }
        });

        l3.setText("Lab3");

        jLabel3.setText("Last Visit");

        Cancel.setText("Cancel");
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Panel2Layout = new javax.swing.GroupLayout(Panel2);
        Panel2.setLayout(Panel2Layout);
        Panel2Layout.setHorizontalGroup(
            Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addComponent(Vid, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(IDF, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(47, 47, 47))
                            .addGroup(Panel2Layout.createSequentialGroup()
                                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(l3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(l4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(Panel2Layout.createSequentialGroup()
                                .addComponent(l1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lab4c, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lab3c, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lab2c, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(visitedDate, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lab1c, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(l2com, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(l1com, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(l3com, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(l4com, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(namel, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(namef, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(rl2, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rl1, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rl3, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rl4, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(64, 64, 64))))
            .addGroup(Panel2Layout.createSequentialGroup()
                .addGap(254, 254, 254)
                .addComponent(firstVisit, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(Next, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Cancel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Panel2Layout.setVerticalGroup(
            Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel2Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(IDF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Vid, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(namel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(namef, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(l1com, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Panel2Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(rl1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(15, 15, 15))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lab1c, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(l1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)))
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lab2c, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(l2com, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(rl2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(l2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lab3c, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(l3com, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(rl3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(l3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(lab4c, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(rl4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(l4com, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(l4, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(46, 46, 46)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(visitedDate, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addComponent(firstVisit, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(134, 185, Short.MAX_VALUE))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Next)
                            .addComponent(Cancel))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        layeredPane.add(Panel2, "card3");

        jLabel5.setText("ID");

        jLabel7.setText("Name");

        jLabel8.setText("LabId");

        jLabel9.setText("Date & Time");

        jLabel11.setText("Lab Technician ID");

        reasonList.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reason 1", "Reason 2", "Reason 3", "Reason 4" }));
        reasonList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reasonListActionPerformed(evt);
            }
        });

        reasoncom.setText("Select Reason :");

        jLabel13.setText("Time Allowed");

        timeAvail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeAvailActionPerformed(evt);
            }
        });

        jLabel14.setText("Phone Number");

        submit.setText("Finish");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Panel3Layout = new javax.swing.GroupLayout(Panel3);
        Panel3.setLayout(Panel3Layout);
        Panel3Layout.setHorizontalGroup(
            Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel3Layout.createSequentialGroup()
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Panel3Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(PCTID, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Panel3Layout.createSequentialGroup()
                                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(47, 47, 47)
                                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(LABid, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dateTime, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(42, 42, 42)
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(Panel3Layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addComponent(PCTName, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Panel3Layout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(67, 67, 67)
                                .addComponent(LabTechID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addContainerGap(208, Short.MAX_VALUE))
                    .addGroup(Panel3Layout.createSequentialGroup()
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(reasoncom, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(59, 59, 59)
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(reasonList, 0, 143, Short.MAX_VALUE)
                            .addComponent(timeAvail)
                            .addComponent(phno))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(submit)
                        .addGap(90, 90, 90))))
        );
        Panel3Layout.setVerticalGroup(
            Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel3Layout.createSequentialGroup()
                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(Panel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PCTName, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Panel3Layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(PCTID, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel3Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LABid, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel3Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LabTechID, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateTime, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reasoncom, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reasonList, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeAvail, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(submit)
                        .addComponent(phno, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(219, Short.MAX_VALUE))
        );

        layeredPane.add(Panel3, "card4");

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Welcome to Application");

        jDesktopPane1.setLayer(layeredPane, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(TechId, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(layeredPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TechId, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)))
                .addContainerGap())
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(TechId, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)))
                .addComponent(layeredPane, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
// Browse Button for browsing img file
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        JFileChooser fp=new JFileChooser();
        fp.showOpenDialog(this);
        File f=fp.getSelectedFile();
        String filename=f.getAbsolutePath();
        input_img=filename;
        fileDisplay.setText(filename);          
    }//GEN-LAST:event_jButton1ActionPerformed
//upload button for OCR to fetch ID
    private void uplActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uplActionPerformed
        OCR.ocrmain(input_img,"ocr");
        try {
            File x=new File("C:\\Users\\Prashant Varshney\\Documents\\ocr.txt");
            id=ReadId.ReadText(x);
            idpresent =ReadExcel.searchID(id);
            //if id is not present in DataBase
            if(!idpresent) {
                PCTID.setText(id);
                LabTechID.setText(TId);
                LABid.setText(LabID);
                switchPanels(Panel3);
            }
            //if id is found fetching previous lab records
            else {
                int LabVisitwithReasons[]=ReadExcel.labSearch(id,LabID);
                int LabVisit[]=new int[4];
                for(int i=0,j=0;i<16;i++) {
                    if((i/4)>j)j++;
                   LabVisit[j]+=LabVisitwithReasons[i];
                    f+=LabVisitwithReasons[i];
                }
                
                int labID=Integer.parseInt(LabID);
                //If visiting the Lab for first time
                if(LabVisit[labID-1]==0) {
                    
                    firstVisit.setText("Visiting this Lab"+labID+" for first time");
                    userData=ReadExcel.ReadData(id);
                    lab1c.setText(Integer.toString(LabVisit[0]));
                    lab2c.setText(Integer.toString(LabVisit[1]));
                    lab3c.setText(Integer.toString(LabVisit[2]));
                    lab4c.setText(Integer.toString(LabVisit[3]));
                    namef.setText(userData[1]);
                    IDF.setText(userData[0]);
                    switchPanels(Panel2);
                    //if none of the Labs is visited in past
                    if(f==0){
                    firstVisit.setText("NO LABS Visited");
                    JOptionPane.showMessageDialog(Panel2,"Click Next to enter data else click Cancel ");}
                    
                }//if previous lab records are found
                else
                {
                    userData=ReadExcel.ReadData(id);
                    System.out.println("after read userdataa");                  
                IDF.setText(userData[0]);
                namef.setText(userData[1]);
                lab1c.setText(Integer.toString(LabVisit[0]));
                lab2c.setText(Integer.toString(LabVisit[1]));
                lab3c.setText(Integer.toString(LabVisit[2]));
                lab4c.setText(Integer.toString(LabVisit[3]));
                visitedDate.setText(userData[21]);
                switchPanels(Panel2);
                }
            }
        }
        catch(NumberFormatException e)
        {
            e.printStackTrace();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_uplActionPerformed
//Entering new lab record
    private void NextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextActionPerformed
        switchPanels(Panel3);
        PCTID.setText(id);
        userData[0]=id;
        if(idpresent)
        {
            PCTName.setText(userData[1]);
            phno.setText(userData[19]);
            PCTName.setEditable(false);
        }
        userData[1]=PCTName.getText();
        LABid.setText(LabID);
        LabTechID.setText(TId);
        userData[20]=TId;
        DateFormat df=new SimpleDateFormat("dd/MM/yyyy");
        data=df.format(new Date());
        dateTime.setText(data);
        userData[21]=data;
        userData[22]=timeAvail.getText();
        userData[19]=phno.getText();
        userData[18]=Integer.toString(f);
    }//GEN-LAST:event_NextActionPerformed

    private void timeAvailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeAvailActionPerformed
     
    }//GEN-LAST:event_timeAvailActionPerformed
//Response is recorded and data is uploaded to excel database
    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
    userData[0]=id;
    userData[1]=PCTName.getText();
    userData[20]=TId;
    DateFormat df=new SimpleDateFormat("dd/MM/yyyy");
    data=df.format(new Date());
    dateTime.setText(data);
    userData[21]=data;
    userData[22]=timeAvail.getText();
    userData[19]=phno.getText();
        WriteExcel obj=new WriteExcel();
        try {
            obj.writeData(userData,idpresent);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (WriteException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BiffException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        JOptionPane.showMessageDialog(EntryPanel, "Your Response has been recorded");
        switchPanels(EntryPanel);
    }//GEN-LAST:event_submitActionPerformed
//Logging into app
    private void EntertoappActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EntertoappActionPerformed
TId=Tid.getText();
      switch((String)LabItem.getSelectedItem()){
    case "Lab 1": LabID="1"; break;
    case "Lab 2": LabID="2"; break;
    case "Lab 3": LabID="3"; break;
    case "Lab 4": LabID="4"; break;
    default : LabID="1";
}
switchPanels(Panel1);
TechId.setText("Technician ID : "+TId);

    }//GEN-LAST:event_EntertoappActionPerformed
//Exit button
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
System.exit(0);       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void LabItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LabItemActionPerformed
  
    }//GEN-LAST:event_LabItemActionPerformed
//Cancel Button
    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
switchPanels(EntryPanel);        
    }//GEN-LAST:event_CancelActionPerformed
//Display reason counts of respective labs
    private void l1comActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l1comActionPerformed
        switch((String)l1com.getSelectedItem()){
    case "Reason 1": rl1.setText(userData[2]); break;
    case "Reason 2": rl1.setText(userData[3]); break;
    case "Reason 3": rl1.setText(userData[4]); break;
    case "Reason 4": rl1.setText(userData[5]); break;
}
    }//GEN-LAST:event_l1comActionPerformed

    private void l2comActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l2comActionPerformed
        switch((String)l2com.getSelectedItem()){
    case "Reason 1": rl2.setText(userData[6]); break;
    case "Reason 2": rl2.setText(userData[7]); break;
    case "Reason 3": rl2.setText(userData[8]); break;
    case "Reason 4": rl2.setText(userData[9]); break;
}        // TODO add your handling code here:
    }//GEN-LAST:event_l2comActionPerformed

    private void l3comActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l3comActionPerformed
         switch((String)l3com.getSelectedItem()){
    case "Reason 1": rl3.setText(userData[10]); break;
    case "Reason 2": rl3.setText(userData[11]); break;
    case "Reason 3": rl3.setText(userData[12]); break;
    case "Reason 4": rl3.setText(userData[13]); break;
}
    }//GEN-LAST:event_l3comActionPerformed

    private void l4comActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l4comActionPerformed
                switch((String)l4com.getSelectedItem()){
    case "Reason 1": rl4.setText(userData[14]); break;
    case "Reason 2": rl4.setText(userData[15]); break;
    case "Reason 3": rl4.setText(userData[16]); break;
    case "Reason 4": rl4.setText(userData[17]); break;
 
}
    }//GEN-LAST:event_l4comActionPerformed
//Selecting a reason for entering a lab
    private void reasonListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reasonListActionPerformed
        int n=4*Integer.parseInt(LabID)-3;
        int r=1;
        switch((String)reasonList.getSelectedItem()){
    case "Reason 1": r=1; break;
    case "Reason 2": r=2; break;
    case "Reason 3": r=3; break;
    case "Reason 4": r=4; break;
    default : r=1;
        }
        n=n+r;
        try{
        userData[n]=Integer.toString(Integer.parseInt(userData[n])+1);
        }
        catch(NumberFormatException e)
        {
            userData[n]="1";
        }
     
    }//GEN-LAST:event_reasonListActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }
 //Function for switching between panels
    public void switchPanels(JPanel panel){
        layeredPane.removeAll();
        layeredPane.add(panel);
        layeredPane.repaint();
        layeredPane.revalidate();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancel;
    private javax.swing.JButton Entertoapp;
    private javax.swing.JPanel EntryPanel;
    private javax.swing.JLabel IDF;
    private javax.swing.JLabel LABid;
    private javax.swing.JComboBox<String> LabItem;
    private javax.swing.JLabel LabTechID;
    private javax.swing.JButton Next;
    private javax.swing.JLabel PCTID;
    private javax.swing.JTextField PCTName;
    private javax.swing.JPanel Panel1;
    private javax.swing.JPanel Panel2;
    private javax.swing.JPanel Panel3;
    private javax.swing.JLabel TechId;
    private javax.swing.JTextField Tid;
    private javax.swing.JLabel Vid;
    private javax.swing.JLabel dateTime;
    private javax.swing.JLabel fileDisplay;
    private javax.swing.JLabel firstVisit;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel l1;
    private javax.swing.JComboBox<String> l1com;
    private javax.swing.JLabel l2;
    private javax.swing.JComboBox<String> l2com;
    private javax.swing.JLabel l3;
    private javax.swing.JComboBox<String> l3com;
    private javax.swing.JLabel l4;
    private javax.swing.JComboBox<String> l4com;
    private javax.swing.JLabel lab1c;
    private javax.swing.JLabel lab2c;
    private javax.swing.JLabel lab3c;
    private javax.swing.JLabel lab4c;
    private javax.swing.JLayeredPane layeredPane;
    private javax.swing.JLabel namef;
    private javax.swing.JLabel namel;
    private javax.swing.JTextField phno;
    private javax.swing.JComboBox<String> reasonList;
    private javax.swing.JLabel reasoncom;
    private javax.swing.JLabel rl1;
    private javax.swing.JLabel rl2;
    private javax.swing.JLabel rl3;
    private javax.swing.JLabel rl4;
    private javax.swing.JButton submit;
    private javax.swing.JTextField timeAvail;
    private javax.swing.JButton upl;
    private javax.swing.JLabel visitedDate;
    // End of variables declaration//GEN-END:variables
}
